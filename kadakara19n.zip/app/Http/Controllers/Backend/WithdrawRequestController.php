<?php

namespace App\Http\Controllers\Backend;
// use App\Models\UsersModel;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\User;
use App\UsersWalletDetailsModel;
use Razorpay\Api\Api;
use Session;
use Redirect;


class WithdrawRequestController extends Controller
{
	public function withdraw_request_list(Request $request)
	{	
		$getrecord = UsersWalletDetailsModel::orderBy('id', 'desc')->select('users_wallet_details.*');
		$getrecord = $getrecord->join('users', 'users_wallet_details.user_id', '=', 'users.id');
		// Search Box Start

		if ($request->idsss) {
            $getrecord = $getrecord->where('users_wallet_details.id', '=', $request->idsss);
        }

        if(!empty($request->name)){
           $getrecord = $getrecord->where('users.name', 'like', '%' . $request->name . '%');
        }

     
        if ($request->money_status) {
            $money_status = $request->money_status;
            if($request->money_status == 100)
            {
                $money_status = 0;
            }

            $getrecord = $getrecord->where('money_status','=',$money_status);
        }
		// Search Box End
		
		$getrecord = $getrecord->paginate(40);
		$data['getrecord'] = $getrecord;
		$data['meta_title'] = 'Withdraw Request List';
		return view('backend.withdraw_request.list', $data);
	}


	public function pay_now($id){

        $getrecord = UsersWalletDetailsModel::get_single($id);
		$getrecord->money_status = '1';
		$getrecord->save();

        return redirect()->back()->with('success', 'Payment successfull');
	}


	// 

	public function create(){
		 return view('backend.withdraw_request.list_v');
	}

	 public function payment(Request $request, $id)
    {
        $input = $request->all();

        $api = new Api(env('RAZOR_KEY'), env('RAZOR_SECRET'));

        $payment = $api->payment->fetch($input['razorpay_payment_id']);

        if(count($input)  && !empty($input['razorpay_payment_id'])) {
            try {
                $response = $api->payment->fetch($input['razorpay_payment_id'])->capture(array('amount'=>$payment['amount'])); 

            } catch (\Exception $e) {
                return  $e->getMessage();
                \Session::put('error',$e->getMessage());
                return redirect()->back();
            }
        }
        
        // \Session::put('success', 'Payment successful');
     
        $getrecord = UsersWalletDetailsModel::get_single($id);
		$getrecord->money_status = '1';
		$getrecord->save();
     //   return redirect()->back();
           return redirect()->back()->with('success', 'Payment successfull');
    }

}

?>