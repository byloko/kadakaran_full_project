<!DOCTYPE html>
<html>
<head>
	<title>404 Page not found..</title>
	 <link rel="icon" href="{{ url('public/img/favicons.png') }}" type="image/x-icon" />
</head>
<body>
<div>
	<center>
  <aside><img src="{{ url('public/img/card.jpg') }}" alt="404 Image" height="600px;" />
  </aside>
  </center>

  
</div>
</body>
</html>

