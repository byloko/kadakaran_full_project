<!DOCTYPE html>
<html>
<head>
	  <link rel="icon" href="{{ url('public/img/favicons.png') }}" type="image/x-icon" />
	<title>Kadakaran | Email Verification</title>
</head>
<body>

	  <img src="{{ url('upload/email_verification.jpg') }}" style="display: block;margin-left: auto;margin-right: auto;max-height: 450px;" alt="">

</body>
</html>