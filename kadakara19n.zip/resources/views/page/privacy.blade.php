<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Kadakaran | Privacy Policies</title>
        <link rel="icon" href="{{ url('public/img/favicons.png') }}" type="image/x-icon" />
        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
    </head>
    <body>

      <center>
          <aside>
            
            <img src="{{ url('public/img/privacy.jpg') }}" alt="404 Image" height="400px;" />
          </aside>
          <a style="font-size: 20px;" href="{{ url('/') }}">Back</a>
       </center>
       
    </body>
</html>
